

Desenvolvimento Jovem Programador - Java Web PJP

Projeto Pequenos Passos

Gestor de tarefa para Pais (4-6) ANOS

Objetivo para os pais acompanharem o desenvolvimento dos filhos de forma lúdica e organizada, além de servir como um guia para os pais, ele dará sugestões automáticas de tarefas baseadas na idade e desenvolvimento infantil.

Categorias: Psicomotricidade: Atividades que estimulam coordenação motora e habilidades físicas. Psicoeducação: Exercícios para ensinar emoções, empatia e habilidades sociais. Cuidados com a Saúde: Higiene, alimentação saudável, hábitos de sono. Vacinação: Calendário e lembretes de vacinação.

Contribuição : Kathlen Caroline de Souza, Gabriel Sant'Anna, Maria Isabel Klein Delavy, Rafaela Helena Garbin Rudolf Nascimento.
